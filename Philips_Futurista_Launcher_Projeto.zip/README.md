# Philips Futurista Launcher 1.0

Projeto inicial de launcher para Android TV 11, desenvolvido sem Compose para manter a interface simples e leve.

## O que esta primeira versão faz
- Registra uma atividade HOME/LEANBACK_LAUNCHER.
- Lista aplicativos de TV disponíveis (com fallback para aplicativos launcher).
- Abre aplicativos pelo controle remoto.
- Interface escura futurista com realce ciano de foco.

## Compilar sem computador
1. Crie uma conta no GitHub e um repositório vazio.
2. No navegador do celular, abra o repositório e envie os arquivos deste projeto.
3. Abra a aba **Actions** e execute **Build Philips Futurista APK** (ou aguarde o build após enviar para `main`).
4. Abra a execução concluída e baixe o artefato `Philips-Futurista-debug`.
5. Extraia o APK no celular e transfira para a TV por um método de instalação local/rede.

## Observações
- Este é um protótipo inicial, não um APK já compilado.
- O Android 11 pode limitar a visibilidade de aplicativos; a lista usa consultas de intents.
- A seleção como launcher padrão depende do firmware da Philips. Mantenha o launcher original disponível.
- O relógio nesta versão é atualizado quando a tela é recriada; atualização contínua será adicionada na próxima versão.
