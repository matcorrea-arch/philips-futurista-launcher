package br.com.philips.futurista

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class TvApp(val label: String, val packageName: String, val launchIntent: Intent)

class MainActivity : Activity() {
    private val bg = Color.rgb(7, 12, 27)
    private val cyan = Color.rgb(0, 220, 255)
    private lateinit var root: LinearLayout
    private lateinit var appGrid: LinearLayout
    private val apps = mutableListOf<TvApp>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        buildScreen()
        loadApps()
        renderApps()
    }

    private fun buildScreen() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(42, 28, 42, 28)
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(8, 17, 39), Color.rgb(12, 10, 31), Color.rgb(3, 8, 19))
            )
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = TextView(this).apply {
            text = "PHILIPS  /  FUTURISTA"
            textSize = 17f
            letterSpacing = 0.18f
            setTextColor(cyan)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        }
        val clock = TextView(this).apply {
            text = SimpleDateFormat("HH:mm   •   EEEE, dd MMM", Locale("pt", "BR")).format(Date())
            textSize = 15f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
        }
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(clock)
        root.addView(header)

        val title = TextView(this).apply {
            text = "SEU UNIVERSO DIGITAL"
            textSize = 29f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            setPadding(0, 34, 0, 4)
        }
        root.addView(title)
        val subtitle = TextView(this).apply {
            text = "APLICATIVOS"
            textSize = 12f
            letterSpacing = 0.24f
            setTextColor(cyan)
            setPadding(0, 14, 0, 14)
        }
        root.addView(subtitle)

        appGrid = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.TOP
        }
        root.addView(appGrid, LinearLayout.LayoutParams(-1, 0, 1f))
        val footer = TextView(this).apply {
            text = "Use as setas para navegar  •  OK para abrir  •  HOME para voltar"
            textSize = 12f
            setTextColor(Color.rgb(125, 151, 177))
            setPadding(0, 12, 0, 0)
        }
        root.addView(footer)
        setContentView(root)
    }

    @Suppress("DEPRECATION")
    private fun loadApps() {
        val pm = packageManager
        val leanback = Intent(Intent.ACTION_MAIN).addCategory("android.intent.category.LEANBACK_LAUNCHER")
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val found = LinkedHashMap<String, TvApp>()
        val candidates = try { pm.queryIntentActivities(leanback, PackageManager.MATCH_ALL) } catch (_: Exception) { emptyList() }
        val all = if (candidates.isNotEmpty()) candidates else pm.queryIntentActivities(launcher, PackageManager.MATCH_ALL)
        for (info in all) {
            val pkg = info.activityInfo.packageName
            if (pkg == packageName || found.containsKey(pkg)) continue
            val launch = pm.getLaunchIntentForPackage(pkg) ?: continue
            val label = info.loadLabel(pm)?.toString() ?: pkg
            found[pkg] = TvApp(label, pkg, launch)
        }
        apps.clear()
        apps.addAll(found.values.sortedBy { it.label.lowercase(Locale.getDefault()) })
    }

    private fun renderApps() {
        appGrid.removeAllViews()
        val visible = apps.take(8)
        for ((index, app) in visible.withIndex()) {
            val tile = TextView(this).apply {
                text = app.label.uppercase(Locale.getDefault())
                textSize = 15f
                letterSpacing = 0.06f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                isFocusable = true
                isFocusableInTouchMode = true
                background = tileBackground(false)
                setPadding(12, 12, 12, 12)
                contentDescription = "Abrir ${app.label}"
                setOnFocusChangeListener { v, hasFocus -> v.background = tileBackground(hasFocus) }
                setOnClickListener { try { startActivity(app.launchIntent) } catch (_: Exception) { } }
            }
            val lp = LinearLayout.LayoutParams(0, 150, 1f)
            lp.setMargins(7, 8, 7, 8)
            appGrid.addView(tile, lp)
            if (index == 0) tile.requestFocus()
        }
        if (visible.isEmpty()) {
            val empty = TextView(this).apply {
                text = "Nenhum aplicativo encontrado."
                textSize = 18f
                setTextColor(Color.WHITE)
            }
            appGrid.addView(empty)
        }
    }

    private fun tileBackground(focused: Boolean): GradientDrawable {
        return GradientDrawable().apply {
            cornerRadius = 18f
            setColor(if (focused) Color.rgb(20, 53, 77) else Color.rgb(18, 27, 48))
            setStroke(if (focused) 3 else 1, if (focused) cyan else Color.rgb(45, 67, 94))
        }
    }

    override fun onResume() {
        super.onResume()
        if (::appGrid.isInitialized) {
            loadApps()
            renderApps()
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_HOME) return true
        return super.onKeyDown(keyCode, event)
    }
}
